// Fill out your copyright notice in the Description page of Project Settings.


#include "BlueTile.h"
#include "RgsTileGameMode.h"

void ABlueTile::BeginPlay()
{
	Super::BeginPlay();
    
	GameMode = Cast<ARgsTileGameMode>(GetWorld()->GetAuthGameMode());
}

void ABlueTile::StepOn(bool blueTilePress)
{
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(ColorToSet));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 1.0f);
	if(GameMode){
		GameMode->ToggleGreenTilesShow(true);
	}
}

void ABlueTile::StepOff(bool blueTilePress)
{
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(FColor::Silver));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 0.0f);
	if(GameMode)
	{
		GameMode->ToggleGreenTilesShow(false);
	}
}