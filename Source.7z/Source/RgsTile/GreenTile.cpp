// Fill out your copyright notice in the Description page of Project Settings.


#include "GreenTile.h"

void AGreenTile::StepOn(bool blueTilePress)
{
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(ColorToSet));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 1.0f);
	if(!blueTilePress)
	{
		hasBeenSteppedOn = true;
	}
}

void AGreenTile::StepOff(bool blueTilePress)
{
	if(!blueTilePress || hasBeenSteppedOn) return;
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(FColor::Silver));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 0.0f);
}