// Fill out your copyright notice in the Description page of Project Settings.


#include "RedTile.h"


void ARedTile::StepOn(bool blueTilePress)
{
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(ColorToSet));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 1.0f);
	hasBeenSteppedOn = true;
}

void ARedTile::StepOff(bool blueTilePress)
{
	MeshComponent->SetVectorParameterValueOnMaterials(FName("TileBaseColor"), FVector(ColorToSet));
	MeshComponent->SetScalarParameterValueOnMaterials(FName("TileEmission"), 0.0f);
}