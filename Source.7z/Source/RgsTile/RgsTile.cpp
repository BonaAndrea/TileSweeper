// Copyright(c) Forge Reply. All Rights Reserved.

#include "RgsTile.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, RgsTile, "RgsTile" );
